/**
 * Mathematics for swerve drives. Original second order kinematics was developed by Team 3181
 * <a href="https://github.com/pittsfordrobotics/ChargedUp2023/tree/master/src/main/java/com/team3181/lib/swerve">here.
 * </a>
 */
package swervelib.math;
