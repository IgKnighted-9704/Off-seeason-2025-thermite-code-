/**
 * Deserialize specific variables for outside the parser.
 */
package swervelib.parser.deserializer;
