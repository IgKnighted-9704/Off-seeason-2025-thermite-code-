/**
 * Yet-Another Generic Swerve Library (YAGSL) main package AKA swervelib.
 *
 * @version 1.0.0
 */
package swervelib;
